<?php
/*************************************************************************************
   Copyright notice
   
   (c) 2002-2011 Oliver Georgi (oliver@phpwcms.de) // All rights reserved.
 
   This script is part of PHPWCMS. The PHPWCMS web content management system is
   free software; you can redistribute it and/or modify it under the terms of
   the GNU General Public License as published by the Free Software Foundation;
   either version 2 of the License, or (at your option) any later version.
  
   The GNU General Public License can be found at http://www.gnu.org/copyleft/gpl.html
   A copy is found in the textfile GPL.txt and important notices to the license 
   from the author is found in LICENSE.txt distributed with these scripts.
  
   This script is distributed in the hope that it will be useful, but WITHOUT ANY 
   WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
   PARTICULAR PURPOSE.  See the GNU General Public License for more details.
 
   This copyright notice MUST APPEAR in all copies of the script!
*************************************************************************************/

// ----------------------------------------------------------------
// obligate check for phpwcms constants
if (!defined('PHPWCMS_ROOT')) {
   die("You Cannot Access This Script Directly, Have a Nice Day.");
}
// ----------------------------------------------------------------


$new_login 			= genlogname();
$new_password 		= generic_string(8);
$new_email			= '';
$new_name			= '';
$set_user_aktiv 	= 0;
$set_user_admin 	= 0;
$set_user_fe		= 0;
$send_verification	= 1;
$user_err			= '';
				
if(isset($_POST["form_aktion"]) && $_POST["form_aktion"] == "create_account") {
	//Create Account Daten verarbeiten
	$new_login 			= slweg($_POST["form_newloginname"]);
	$new_password 		= slweg($_POST["form_newpassword"]);
	$new_email 			= clean_slweg($_POST["form_newemail"]);
	$new_name 			= clean_slweg($_POST["form_newrealname"]);
	$set_user_aktiv 	= isset($_POST["form_active"]) ? 1 : 0;
	$set_user_admin 	= isset($_POST["form_admin"]) ? 1 : 0;
	$set_user_fe 		= isset($_POST["form_feuser"]) ? intval($_POST["form_feuser"]) : 0;
	if($set_user_admin) {
		$set_user_fe 	= 2;
	}
	$send_verification 	= isset($_POST["verification_email"]) ? 1 : 0;
	if(isEmpty($new_login)) {
		$user_err = $BL['be_admin_usr_err2']."\n";
	} else {
		$sql = "SELECT COUNT(*) AS anzahl FROM ".DB_PREPEND."phpwcms_user WHERE usr_login='".aporeplace($new_login)."'";
		if($result = mysql_query($sql, $db)) {
			if($check_anzahl = mysql_fetch_array($result)) {
				if($check_anzahl["anzahl"]) $user_err .= $BL['be_admin_usr_err1']."\n";
			}
			mysql_free_result($result);
		}
	}
	if(isEmpty($new_password)) $user_err .= $BL['be_admin_usr_err3']."\n";
	if(!is_valid_email($new_email) && $send_verification) $user_err .= $BL['be_admin_usr_err4']."\n";
	if(empty($user_err)) { //Insert new User
		$sql =	"INSERT INTO ".DB_PREPEND."phpwcms_user (usr_login, usr_pass, usr_email, ".
				"usr_admin, usr_aktiv, usr_name, usr_wysiwyg, usr_fe ) VALUES ('".
				aporeplace($new_login)."', '".
				aporeplace(md5(makeCharsetConversion($new_password, PHPWCMS_CHARSET, 'utf-8')))."', '".
				aporeplace($new_email)."', '".
				$set_user_admin."', '".
				$set_user_aktiv."', '".
				aporeplace($new_name)."', '".
				$GLOBALS['phpwcms']['wysiwyg_editor']."', '".
				$set_user_fe."')";
		if(mysql_query($sql, $db) or die('error while creating new user')) {
			$new_user_id = mysql_insert_id($db);
			$user_ok = 1;
			if($send_verification) {
				$emailbody = str_replace('{LOGIN}',    $new_login,       $BL['be_admin_usr_mailbody']);
				$emailbody = str_replace('{PASSWORD}', $new_password,    $emailbody);
				$emailbody = str_replace('{SITE}',     PHPWCMS_URL, $emailbody);
				$emailbody = str_replace('{LOGIN_PAGE}',     PHPWCMS_URL.get_login_file(), $emailbody);

				sendEmail(	array(
					'recipient'	=> $new_email,
					'toName'	=> $new_name,
					'subject'	=> $BL['be_admin_usr_mailsubject'],
					'isHTML'	=> 0,
					'text'		=> $emailbody,
					'from'		=> $phpwcms["admin_email"],
					'sender'	=> $phpwcms["admin_email"]
				        ));
				//@mail($new_email,$BL['be_admin_usr_mailsubject'],$emailbody, "From: ".$phpwcms["admin_email"]."\nReply-To: ".$phpwcms["admin_email"]."\n");
			}
		}					
	}				
}
				
if(empty($user_ok)) {
		
?><form action="phpwcms.php?do=admin&amp;s=1" method="post" name="edituser"><table border="0" cellpadding="0" cellspacing="0" summary="">
          <tr> 
            <td colspan="2"><table border="0" cellpadding="0" cellspacing="0" summary="">
                <tr>
                  <td><img src="img/usricon/usr_add.gif" alt="" width="19" height="16"></td>
                  <td class="title">&nbsp;<?php echo $BL['be_admin_usr_title'] ?></td>
                </tr>
              </table></td>
          </tr>
          <tr> 
            <td><img src="img/leer.gif" alt="" width="105" height="1"></td>
            <td><img src="img/leer.gif" alt="" width="1" height="5"></td>
          </tr>
		  <?php
		  if(!empty($user_err)) {
		  ?>
          <tr valign="top">
            <td align="right"><strong style="color:#FF3300"><?php echo $BL['be_admin_usr_err'] ?>:</strong>&nbsp;</td>
            <td><strong style="color:#FF3300"><?php echo nl2br(chop($user_err)) ?></strong></td>
          </tr>
          <tr valign="top"><td colspan="2" align="right" class="chatlist"><img src="img/leer.gif" alt="" width="1" height="7"></td></tr>
		  <?php
		  } //Ende Fehler New User
		  ?>
          <tr> 
            <td align="right" class="chatlist"><?php echo $BL["login_username"]  ?>:&nbsp;</td>
            <td><input name="form_newloginname" type="text" id="form_newloginname" style="font-family: Verdana, Arial, Helvetica, sans-serif; width:250px; font-size: 11px; font-weight: bold;" value="<?php echo $new_login ?>" size="30" maxlength="30"></td>
          </tr>
          <tr><td colspan="2"><img src="img/leer.gif" alt="" width="1" height="1"></td></tr>
          <tr> 
            <td align="right" class="chatlist"><?php echo $BL["login_userpass"] ?>:&nbsp;</td>
            <td><input name="form_newpassword" type="text" id="form_newpassword" style="font-family: Verdana, Arial, Helvetica, sans-serif; width:250px; font-size: 11px; font-weight: bold;" value="<?php echo $new_password ?>" size="30" maxlength="20"></td>
          </tr>
          <tr><td colspan="2"><img src="img/leer.gif" alt="" width="1" height="1"></td></tr>
          <tr> 
            <td align="right" class="chatlist"><?php echo $BL['be_profile_label_email'] ?>:&nbsp;</td>
            <td><input name="form_newemail" type="text" id="form_newemail" style="font-family: Verdana, Arial, Helvetica, sans-serif; width:250px; font-size: 11px; font-weight: bold;" value="<?php echo $new_email ?>" size="30" maxlength="150"></td>
          </tr>
          <tr><td colspan="2"><img src="img/leer.gif" alt="" width="1" height="1"></td></tr>
          <tr> 
            <td align="right" class="chatlist"><?php echo $BL['be_admin_usr_realname'] ?>:&nbsp;</td>
            <td><input name="form_newrealname" type="text" id="form_newrealname" style="font-family: Verdana, Arial, Helvetica, sans-serif; width:250px; font-size: 11px; font-weight: bold;" value="<?php echo $new_name ?>" size="30" maxlength="80"></td>
          </tr>
		  
		  <tr><td colspan="2"><img src="img/leer.gif" alt="" width="1" height="6"></td></tr>
          <tr> 
            <td align="right" class="chatlist"><?php echo $BL['be_admin_usr_issection']  ?>:&nbsp;</td>
            <td><table border="0" cellpadding="0" cellspacing="0" bgcolor="#E7E8EB" summary="">
                <tr> 
                  <td><input name="form_feuser" type="radio" id="form_feuser0" value="0"<?php is_checked($set_user_fe, 0); ?>></td>
                  <td><label for="form_feuser0"><?php echo $BL['be_admin_usr_ifsection0'] ?></label>&nbsp;&nbsp;</td>
				  <td><input name="form_feuser" type="radio" id="form_feuser1" value="1"<?php is_checked($set_user_fe, 1); ?>></td>
                  <td><label for="form_feuser1"><?php echo $BL['be_admin_usr_ifsection1'] ?></label>&nbsp;&nbsp;</td>
				  <td><input name="form_feuser" type="radio" id="form_feuser2" value="2"<?php is_checked($set_user_fe, 2); ?>></td>
                  <td><label for="form_feuser2"><?php echo $BL['be_admin_usr_ifsection2'] ?></label></td>
				  <td><img src="img/leer.gif" alt="" width="4" height="21"></td>
                </tr>
              </table></td>
          </tr>	
		  
          <tr><td colspan="2"><img src="img/leer.gif" alt="" width="1" height="6"></td></tr>
          <tr> 
            <td align="right" class="chatlist"><?php echo $BL['be_admin_usr_setactive'] ?>:&nbsp;</td>
            <td><table border="0" cellpadding="0" cellspacing="0" summary="">
                <tr> 
                  <td><input name="form_active" type="checkbox" id="form_active" value="1"<?php is_checked($set_user_aktiv, 1); ?>></td>
                  <td><label for="form_active"><?php echo  $BL['be_admin_usr_iflogin'] ?></label></td>
                </tr>
              </table></td>
          </tr>
		  
          <tr><td colspan="2"><img src="img/leer.gif" alt="" width="1" height="1"></td></tr>
          <tr> 
            <td align="right" class="chatlist" style="color:#FF0000"><?php echo $BL['be_admin_usr_isadmin']  ?>:&nbsp;</td>
            <td><table border="0" cellpadding="0" cellspacing="0" summary="">
                <tr> 
                  <td><input name="form_admin" type="checkbox" id="form_admin" value="1"<?php is_checked($set_user_admin, 1); ?>></td>
                  <td><label for="form_admin"><?php echo  $BL['be_admin_usr_ifadmin'] ?> <strong style="color:#FF0000">!!!</strong></label></td>
                </tr>
              </table></td>
          </tr>
		  
		  
		  
		  
          <tr> 
            <td align="right" class="chatlist"><?php echo $BL['be_admin_usr_verify'] ?>:&nbsp;</td>
            <td><table border="0" cellpadding="0" cellspacing="0" summary="">
                <tr><td colspan="3"><img src="img/leer.gif" alt="" width="1" height="6"></td></tr>
                <tr bgcolor="#E7E8EB"> 
                  <td><input name="verification_email" type="checkbox" id="verification_email" value="1"<?php is_checked($send_verification, 1); ?>></td>
                  <td><label for="verification_email"><?php echo $BL['be_admin_usr_sendemail'] ?></label></td>
                  <td><img src="img/leer.gif" alt="" width="4" height="21"></td>
                </tr>
                <tr><td colspan="3"><img src="img/leer.gif" alt="" width="1" height="6"></td></tr>
              </table></td>
          </tr>
          <tr><td colspan="2"><img src="img/leer.gif" alt="" width="1" height="6"><input name="form_aktion" type="hidden" value="create_account"></td></tr>
          <tr> 
            <td>&nbsp;</td>
            <td><input name="Submit" type="submit" class="button10" value="<?php echo $BL['be_admin_usr_button'] ?>"></td>
          </tr>
          <tr><td colspan="2"><img src="img/leer.gif" alt="" width="1" height="15"></td></tr>
      </table></form><img src="img/lines/l538_70.gif" alt="" width="538" height="1"><br /><img src="img/leer.gif" alt="" width="1" height="5"><?php
} else {
	echo "<script language=\"JavaScript\" type=\"text/JavaScript\">\n<!--\n";
	echo "timer=setTimeout(\"self.location.href='phpwcms.php?do=admin'\", 0);\n";
	echo "//-->\n</script>\n";
}
?>