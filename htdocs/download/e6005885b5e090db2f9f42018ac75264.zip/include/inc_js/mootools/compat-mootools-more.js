Fx.Scroll.implement({

	scrollTo: function(y, x){
		return this.start(y, x);
	}

});