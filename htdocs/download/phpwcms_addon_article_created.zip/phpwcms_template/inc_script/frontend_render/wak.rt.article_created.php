<?php

/********************************************
titel:          get_article_created
description:    {WAK_ARTICLE_CREATED}
                {WAK_ARTICLE_CREATED:<DATE_FORMAT>}
                {WAK_ARTICLE_CREATED:<DATE_FORMAT>:<ARTICLE_ID>}
author:         Wolfgang Kubens
last modified:  14.12.2004 created
                07.01.2004 new parameter for date format
                09.01.2004 add the article date format (Pappnase)
********************************************/
function get_article_created($format=NULL,$article_id=NULL) {

  $format = $format ? $format : "short";
  $article_id = $article_id ? $article_id : $GLOBALS["content"]["article_id"];

  $date = '';
  $sql  = 'select article_created from '.DB_PREPEND.'phpwcms_article where article_id = ' .$article_id;

  if($result = mysql_query($sql)) {
    $row  = mysql_fetch_row($result);
    $date = international_date_format(
        $GLOBALS["template_default"]["date"]["language"],
        $GLOBALS["template_default"]["date"][strtolower($format)],
        $row[0]
    );
    mysql_free_result($result);
  }

  return $date;
}

if( ! ( strpos($content["all"],'{WAK_ARTICLE_CREATED')===false ) ) {

  $content["all"] = preg_replace('/\{WAK_ARTICLE_CREATED\}/e','get_article_created();',$content["all"]);
  $content["all"] = preg_replace('/\{WAK_ARTICLE_CREATED:(SHORT|LONG|MEDIUM|ARTICLE)\}/e','get_article_created("$1");',$content["all"]);
  $content["all"] = preg_replace('/\{WAK_ARTICLE_CREATED:(SHORT|LONG|MEDIUM|ARTICLE):(\d+)\}/e','get_article_created("$1","$2");',$content["all"]);

}
?>
