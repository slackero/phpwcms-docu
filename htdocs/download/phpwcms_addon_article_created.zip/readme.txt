This Replacement Tag was initiated by
Wolfgang Kubens

These Replacement Tag will show when an Article was created.

these Settings are Possible

{WAK_ARTICLE_CREATED}
{WAK_ARTICLE_CREATED:<DATE_FORMAT>}
{WAK_ARTICLE_CREATED:<DATE_FORMAT>:<ARTICLE_ID>}

Upload the file into the frontend_render folder.


Oliver "Pappnase" Frohnert
09-01-2005