<?php if (!defined('BB2_CWD')) die("I said no cheating!");
define('BB2_VERSION', "2.1.7");
?>